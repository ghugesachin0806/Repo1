import React from 'react'

const Questions = () => {
  return (
    <div>
      Questions
    </div>
  )
}

export default Questions
